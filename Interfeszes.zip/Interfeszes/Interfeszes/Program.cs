﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Interfeszes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] bemenet = File.ReadAllLines("versenyzok.txt");
            List<Teniszezo> teniszezok = new List<Teniszezo>();
            foreach (string sor in bemenet)
            {
                teniszezok.Add(new Teniszezo(sor));
            }
            Console.WriteLine(string.Join("\n", teniszezok));
            //rendezés -- buboriék rendezés: a szomszédos elemeket összehasonlítom, majd a megfelelő sorrendbe rakom azokat
            //for (int i = 0; i < teniszezok.Count; i++)
            //{
            //    for (int j = 0; j < teniszezok.Count -1; j++)
            //    {
            //        if (teniszezok[j].Score > teniszezok[j + 1].Score)
            //        {
            //            Teniszezo ujT = teniszezok[j];
            //            teniszezok[j] = teniszezok[j+1];
            //            teniszezok[j+1] = ujT;
            //        }
            //    }
            //}
            Console.WriteLine();
            teniszezok.Sort();
            Console.WriteLine(string.Join("\n", teniszezok));
            Console.ReadLine();
        }
    }
}
