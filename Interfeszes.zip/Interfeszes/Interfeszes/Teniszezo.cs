﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Interfeszes
{
    internal class Teniszezo:Versenyzo, IComparable<Teniszezo>
    {
        public int Score { get; set; }

        public Teniszezo() { }

        public Teniszezo(string sor)
        {
            string[] bontas = sor.Split(';');
            Id = int.Parse(bontas[0]);
            Name = (bontas[2]);
            Country = (bontas[1]);
            Score = int.Parse(bontas[3]);
        }

        public override string ToString()
        {
            return $"Név: {Name} Pont: {Score}";
        }

        public int CompareTo(Teniszezo other)
        {
            if (Score < other.Score)
                return -1;
            else if (Score > other.Score)
                return 1;
            else return 0;
        }
    }
}


