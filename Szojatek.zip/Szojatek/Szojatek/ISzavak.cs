﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szojatek
{
    interface ISzavak:IComparable<ISzavak>
    {
        string MagyarKarakteresSzo(int hossz);
        HashSet<char> Karakterek(string szo);
        Dictionary<char, int> Karakterszam();
        
    }
}
