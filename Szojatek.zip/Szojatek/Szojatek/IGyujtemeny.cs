﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szojatek
{
    interface IGyujtemeny
    {

        List<string>LoadFromDatabase(string connStr);

        List<string>LoadFromText(string fileName);

    }
}
