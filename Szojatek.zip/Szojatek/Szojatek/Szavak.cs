﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Szojatek
{
    class Szavak : ISzavak, IGyujtemeny
    {
        Random rnd = new Random();

        List<string> szoGyujtemeny = new List<string>();
        public string Szo { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public List<string> Gyujtemeny { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public List<string> SzoGyujtemeny { get => szoGyujtemeny; set => szoGyujtemeny = value; }

        public int CompareTo(ISzavak other)
        {
            throw new NotImplementedException();
        }

        public HashSet<char> Karakterek(string szo)
        {
            HashSet<char> karakterek = new HashSet<char>();
            foreach (char karakter in szo)
            {
                karakterek.Add(karakter);
            }
            return karakterek;
        }

        public Dictionary<char, int> Karakterszam(string szo)
        {
            Dictionary<char,int> darabszamok = new Dictionary<char,int>();

            foreach (char karakter in szo)
            {
                if (darabszamok.ContainsKey(karakter))
                    darabszamok[karakter]++;
                else
                    darabszamok[karakter] = 1;
            }
            return darabszamok;
        }

        public Dictionary<char, int> Karakterszam()
        {
            throw new NotImplementedException();
        }

        public List<string> LoadFromDatabase(string connStr)
        {
            throw new NotImplementedException();
        }

        public List<string> LoadFromText(string fileName)
        {
            string[] sorok = File.ReadAllLines(fileName);
            List<string> result = new List<string>(sorok);
            return result;
        }

        public string MagyarKarakteresSzo(int hossz)
        {
            string abc = "aábcdeéfghijklmnoóöőpqrstuúüűvwxyz";
            string ujSzo = "";
            for (int i = 0; i < hossz; i++)
            {
                ujSzo += abc[rnd.Next(abc.Length)].ToString();
            }
            return ujSzo;
        }
    }
}
