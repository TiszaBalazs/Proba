﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Szojatek
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Szavak szokezelo = new Szavak();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BetukSzama(object sender, RoutedEventArgs e)
        {
            //előállítjuk a betűk számát
            Dictionary<char, int> betuszam = szokezelo.Karakterszam(tbxUjSzo.Text);
            tbkEredmeny.Text = "";
            foreach (var item in betuszam)
            {
                string ujsor = $"{item.Key}: {item.Value}db";
                tbkEredmeny.Text += ujsor + "\n";
            }
            //a kapott sztinger átadjuk a textBlock-nak
        }

        private void UjSzoGeneralasa(object sender, RoutedEventArgs e)
        {
            tbxUjSzo.Text = szokezelo.MagyarKarakteresSzo(int.Parse(tbxHossz.Text));
            szokezelo.SzoGyujtemeny.Add(tbxUjSzo.Text);
            tbkEredmeny.Text = "";
            tbkEredmeny.Text = string.Join("\n", szokezelo.SzoGyujtemeny);
        }
    }
}
